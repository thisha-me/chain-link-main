// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/access/Ownable.sol";

contract UniversalRegistry is Ownable {

    struct Record {
        bytes value;
        bool exists;
        bool immutableFlag;
    }

    mapping(bytes32 => mapping(bytes32 => Record)) private records;

    event RecordSet(
        bytes32 indexed namespace,
        bytes32 indexed key,
        bytes value,
        address caller,
        uint256 timestamp
    );

    constructor() Ownable(msg.sender) {}

    function setRecord(
        bytes32 namespace,
        bytes32 key,
        bytes calldata value,
        bool immutableFlag
    ) external onlyOwner {
        Record storage record = records[namespace][key];

        if (record.exists && record.immutableFlag) {
            revert("Record is immutable");
        }

        records[namespace][key] = Record({
            value: value,
            exists: true,
            immutableFlag: immutableFlag
        });

        emit RecordSet(namespace, key, value, msg.sender, block.timestamp);
    }

    function getRecord(
        bytes32 namespace,
        bytes32 key
    ) external view returns (bytes memory) {
        return records[namespace][key].value;
    }

    function recordExists(
        bytes32 namespace,
        bytes32 key
    ) external view returns (bool) {
        return records[namespace][key].exists;
    }
}
