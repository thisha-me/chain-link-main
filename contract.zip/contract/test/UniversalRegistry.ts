// SPDX-License-Identifier: MIT
import assert from "node:assert/strict";
import { describe, it } from "node:test";

import { network } from "hardhat";
import { keccak256, toBytes, toHex, encodePacked } from "viem";

describe("UniversalRegistry", async function () {
  const { viem } = await network.connect();
  const publicClient = await viem.getPublicClient();

  // Helper to create bytes32 from string
  const toBytes32 = (str: string): `0x${string}` => {
    return keccak256(toBytes(str));
  };

  describe("Deployment", () => {
    it("Should set the right owner", async function () {
      const [owner] = await viem.getWalletClients();
      const registry = await viem.deployContract("UniversalRegistry");

      const contractOwner = await registry.read.owner();
      assert.equal(contractOwner.toLowerCase(), owner.account.address.toLowerCase());
    });
  });

  describe("setRecord", () => {
    it("Should set a record successfully", async function () {
      const registry = await viem.deployContract("UniversalRegistry");
      const namespace = toBytes32("documents");
      const key = toBytes32("doc1");
      const value = toHex("Hello World");

      await registry.write.setRecord([namespace, key, value, false]);

      const stored = await registry.read.getRecord([namespace, key]);
      assert.equal(stored, value);
    });

    it("Should emit RecordSet event when setting a record", async function () {
      const [owner] = await viem.getWalletClients();
      const registry = await viem.deployContract("UniversalRegistry");
      const deploymentBlockNumber = await publicClient.getBlockNumber();
      const namespace = toBytes32("events");
      const key = toBytes32("event1");
      const value = toHex("Test Event");

      await registry.write.setRecord([namespace, key, value, false]);

      const events = await publicClient.getContractEvents({
        address: registry.address,
        abi: registry.abi,
        eventName: "RecordSet",
        fromBlock: deploymentBlockNumber,
        strict: true,
      });

      assert.equal(events.length, 1);
      assert.equal(events[0].args.namespace, namespace);
      assert.equal(events[0].args.key, key);
      assert.equal(events[0].args.value, value);
      assert.equal(events[0].args.caller?.toLowerCase(), owner.account.address.toLowerCase());
    });

    it("Should allow updating a mutable record", async function () {
      const registry = await viem.deployContract("UniversalRegistry");
      const namespace = toBytes32("mutable");
      const key = toBytes32("key1");
      const value1 = toHex("Version 1");
      const value2 = toHex("Version 2");

      await registry.write.setRecord([namespace, key, value1, false]);
      await registry.write.setRecord([namespace, key, value2, false]);

      const stored = await registry.read.getRecord([namespace, key]);
      assert.equal(stored, value2);
    });

    it("Should reject updating an immutable record", async function () {
      const registry = await viem.deployContract("UniversalRegistry");
      const namespace = toBytes32("immutable-ns");
      const key = toBytes32("immutable-key");
      const value1 = toHex("Locked Value");
      const value2 = toHex("Updated Value");

      // Set as immutable
      await registry.write.setRecord([namespace, key, value1, true]);

      // Try to update - should revert
      try {
        await registry.write.setRecord([namespace, key, value2, false]);
        assert.fail("Expected revert");
      } catch (error: any) {
        assert.ok(error.message.includes("Record is immutable"));
      }
    });

    it("Should reject non-owner from setting records", async function () {
      const [, nonOwner] = await viem.getWalletClients();
      const registry = await viem.deployContract("UniversalRegistry");
      const namespace = toBytes32("unauthorized");
      const key = toBytes32("key");
      const value = toHex("Unauthorized");

      try {
        await registry.write.setRecord([namespace, key, value, false], {
          account: nonOwner.account,
        });
        assert.fail("Expected revert");
      } catch (error: any) {
        assert.ok(error.message.includes("OwnableUnauthorizedAccount"));
      }
    });
  });

  describe("getRecord", () => {
    it("Should return empty bytes for non-existent record", async function () {
      const registry = await viem.deployContract("UniversalRegistry");
      const namespace = toBytes32("empty");
      const key = toBytes32("nonexistent");

      const stored = await registry.read.getRecord([namespace, key]);
      assert.equal(stored, "0x");
    });

    it("Should return correct value for existing record", async function () {
      const registry = await viem.deployContract("UniversalRegistry");
      const namespace = toBytes32("data");
      const key = toBytes32("entry1");
      const value = toHex("Stored Data");

      await registry.write.setRecord([namespace, key, value, false]);

      const stored = await registry.read.getRecord([namespace, key]);
      assert.equal(stored, value);
    });
  });

  describe("recordExists", () => {
    it("Should return false for non-existent record", async function () {
      const registry = await viem.deployContract("UniversalRegistry");
      const namespace = toBytes32("check");
      const key = toBytes32("missing");

      const exists = await registry.read.recordExists([namespace, key]);
      assert.equal(exists, false);
    });

    it("Should return true for existing record", async function () {
      const registry = await viem.deployContract("UniversalRegistry");
      const namespace = toBytes32("check");
      const key = toBytes32("present");
      const value = toHex("Exists");

      await registry.write.setRecord([namespace, key, value, false]);

      const exists = await registry.read.recordExists([namespace, key]);
      assert.equal(exists, true);
    });
  });

  describe("Namespace isolation", () => {
    it("Should isolate records between different namespaces", async function () {
      const registry = await viem.deployContract("UniversalRegistry");
      const namespace1 = toBytes32("namespace1");
      const namespace2 = toBytes32("namespace2");
      const key = toBytes32("sameKey");
      const value1 = toHex("Value in NS1");
      const value2 = toHex("Value in NS2");

      await registry.write.setRecord([namespace1, key, value1, false]);
      await registry.write.setRecord([namespace2, key, value2, false]);

      const stored1 = await registry.read.getRecord([namespace1, key]);
      const stored2 = await registry.read.getRecord([namespace2, key]);

      assert.equal(stored1, value1);
      assert.equal(stored2, value2);
      assert.notEqual(stored1, stored2);
    });
  });
});
