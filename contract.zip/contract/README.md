# UniversalRegistry Smart Contract

A Solidity smart contract for decentralized namespace-based key-value storage with immutable record support. Deployed on Polygon Amoy and Ethereum Sepolia testnets.

## Features

- **Namespace-based Storage** – Organize records by namespace for logical separation
- **Immutable Records** – Optionally lock records permanently after creation
- **Owner-only Access** – Only contract owner can write records
- **Event Logging** – All record changes emit `RecordSet` events with timestamps

## Contract Overview

```solidity
// Set a record (owner only)
function setRecord(bytes32 namespace, bytes32 key, bytes calldata value, bool immutableFlag) external;

// Read a record (public)
function getRecord(bytes32 namespace, bytes32 key) external view returns (bytes memory);

// Check if record exists (public)
function recordExists(bytes32 namespace, bytes32 key) external view returns (bool);
```

## Deployed Addresses

| Network          | Address                                      | Verified |
|------------------|----------------------------------------------|----------|
| Polygon Amoy     | `0x7e4e87F9BF4b99C23143093561F6566Bdbf3E8aE` | ✅ [Sourcify](https://sourcify.dev/server/repo-ui/80002/0x7e4e87F9BF4b99C23143093561F6566Bdbf3E8aE) |
| Ethereum Sepolia | `0x70746265d514840849a0cd646fe7Eb40C5ED759A` | ✅ [Blockscout](https://eth-sepolia.blockscout.com/address/0x70746265d514840849a0cd646fe7Eb40C5ED759A#code) |

## Quick Start

### Prerequisites

- Node.js v22+ (LTS recommended)
- npm or yarn

### Installation

```bash
git clone <repository-url>
cd chain-link-contract
npm install
```

### Configuration

1. Copy the example environment file:
   ```bash
   cp .env.example .env
   ```

2. Edit `.env` with your values:
   ```
   SEPOLIA_RPC_URL=https://sepolia.infura.io/v3/your-api-key
   AMOY_RPC_URL=https://polygon-amoy.infura.io/v3/your-api-key
   SEPOLIA_PRIVATE_KEY=your-private-key
   AMOY_PRIVATE_KEY=your-private-key
   ```

### Compile

```bash
npx hardhat compile
```

### Test

```bash
npx hardhat test
```

**Test Coverage:**
- Deployment & ownership verification
- Record CRUD operations
- Immutable record protection
- Owner-only access control
- Namespace isolation

### Deploy

**To Polygon Amoy:**
```bash
npx hardhat ignition deploy ignition/modules/UniversalRegistry.ts --network amoy
```

**To Ethereum Sepolia:**
```bash
npx hardhat ignition deploy ignition/modules/UniversalRegistry.ts --network sepolia
```

### Verify Contract

After deployment, verify your contract on block explorers to make the source code publicly readable.

#### Get API Keys

1. **Etherscan**: Get API key from [etherscan.io/apis](https://etherscan.io/apis)
2. **Polygonscan**: Get API key from [polygonscan.com/apis](https://polygonscan.com/apis)

Add them to your `.env`:
```
ETHERSCAN_API_KEY=your-etherscan-api-key
POLYGONSCAN_API_KEY=your-polygonscan-api-key
```

#### Verify on Sepolia (Etherscan)

```bash
npx hardhat verify --network sepolia <CONTRACT_ADDRESS>
```

#### Verify on Polygon Amoy (Polygonscan)

```bash
npx hardhat verify --network amoy <CONTRACT_ADDRESS>
```

**Example:**
```bash
npx hardhat verify --network amoy 0xc1a356C55941F308f3ce29E266a89F19e3b297D2
```

> **Note:** The UniversalRegistry contract has no constructor arguments, so no additional parameters are needed.

## Project Structure

```
├── contracts/
│   └── UniversalRegistry.sol    # Main contract
├── ignition/
│   └── modules/
│       └── UniversalRegistry.ts # Deployment module
├── test/
│   └── UniversalRegistry.ts     # Test suite
├── hardhat.config.ts            # Hardhat configuration
├── .env.example                 # Environment template
└── package.json
```

## Tech Stack

- **Solidity** ^0.8.20
- **Hardhat** v3 with Viem toolbox
- **OpenZeppelin** Contracts (Ownable)
- **Node.js** Test Runner

## License

MIT
