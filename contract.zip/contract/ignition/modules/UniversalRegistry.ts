// SPDX-License-Identifier: MIT
import { buildModule } from "@nomicfoundation/hardhat-ignition/modules";

export default buildModule("UniversalRegistryModule", (m) => {
  const universalRegistry = m.contract("UniversalRegistry");

  return { universalRegistry };
});
